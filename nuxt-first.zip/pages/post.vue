<template>
  <h1>POST MAN</h1>
</template>
<script>
export default {

}
</script>
